<?php

$name = $_POST['na']; echo $name; //exit;
$filename = $_FILES['myfile']['name']; //echo $filename;exit;
$tempname = $_FILES['myfile']['tmp_name']; //echo $tempname;exit;
$folder = './image/'.$filename; //echo $folder; exit;

$db = mysqli_connect('localhost', 'root', '', 'sagar');

// Get all the submitted data from form
$sql = "INSERT INTO image(name, dir) VALUES('$name','$filename')";

// Execute Query
mysqli_query($db,$sql);

// Lets move the file to directory
if(move_uploaded_file($tempname,$folder)) {
    echo "<h3>Image Uploaded Successfully</h3>";
    echo "<img src='.$folder.' height='200' width='200'/>";
} else {
    echo "<h3>Failed To Image Upload</h3>";
}
?>