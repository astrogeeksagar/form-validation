<?php
error_reporting(0);
$msg = '';

// IF upload button is clicked
if(isset($_POST['submit'])) {
  $name = $_POST['na']; //echo $name; exit;
  $filename = $_FILES['myfile']['name']; //echo $filename;exit;
  $tempname = $_FILES['myfile']['tmp_name'];
  $folder = './image/'.$filename;$name = $_POST['na']; echo $name; //exit;
  $filename = $_FILES['myfile']['name']; //echo $filename;exit;
  $tempname = $_FILES['myfile']['tmp_name']; //echo $tempname;exit;
  $folder = './image/'.$filename; //echo $folder; exit;
  
  $db = mysqli_connect('localhost', 'root', '', 'sagar');
  
  // Get all the submitted data from form
  $sql = "INSERT INTO image(name, dir) VALUES('$name','$filename')";
  // Execute Query
  mysqli_query($db,$sql);
  
  // Lets move the file to directory
  if(move_uploaded_file($tempname,$folder)) {
      echo "<h3>Image Uploaded Successfully</h3>";
      echo "<img src='image/$filename' height='200' width='200'/>";
  } else {
      echo "<h3>Failed To Image Upload</h3>";
  }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Photo Upload</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<body>

    <div class="container">
        <h2>Photo Upload</h2>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="na" placeholder="Enter Name" name="na">
            </div>
            <div class="mb-3">
                <label for="formFile" class="form-label">Select Photo</label>
                <input class="form-control" type="file" id="myfile" name="myfile">
            </div>
            <input type="submit" id="submit" name="submit" value="Submit" />
        </form>
        <!-- <button type="submit" name="submit" id="submit" class="btn btn-default">Submit</button> -->
    </div>


</body>

</html>